
// Object-oriented prototype models aligned with the proposal's Class Diagram.
class User {
  constructor(userId, fullName, email) {
    this.userId = userId;
    this.fullName = fullName;
    this.email = email;
  }
}
class Subject {
  constructor(subjectId, name, examDate, priority = 3) {
    this.subjectId = subjectId;
    this.name = name;
    this.examDate = new Date(examDate);
    this.priority = priority;
    this.topics = [];
  }
  getDaysUntilExam() {
    return Math.max(0, Math.ceil((this.examDate - new Date()) / 86400000));
  }
  addTopic(topic) { this.topics.push(topic); }
}
class Topic {
  constructor(topicId, title, difficulty, estimatedMinutes, status = 'Pending') {
    this.topicId = topicId;
    this.title = title;
    this.difficulty = difficulty;
    this.estimatedMinutes = estimatedMinutes;
    this.status = status;
  }
  calculatePriority(daysUntilExam) {
    const urgency = 1 / Math.max(1, daysUntilExam);
    const difficultyScore = this.difficulty / 5;
    const incomplete = this.status === 'Completed' ? 0 : 1;
    return 0.45 * urgency + 0.35 * difficultyScore + 0.20 * incomplete;
  }
  markCompleted() { this.status = 'Completed'; }
}
class StudySession {
  constructor(sessionId, topic, durationMinutes, sessionType = 'Study', status = 'Planned') {
    this.sessionId = sessionId;
    this.topic = topic;
    this.durationMinutes = durationMinutes;
    this.sessionType = sessionType;
    this.status = status;
  }
  complete() { this.status = 'Completed'; this.topic.markCompleted(); }
}
class StudyPlan {
  constructor(planId, owner) {
    this.planId = planId;
    this.owner = owner;
    this.sessions = [];
  }
  addSession(session) { this.sessions.push(session); }
  getDailyPlan() { return this.sessions; }
}
class ScheduleGenerator {
  calculatePriority(topic, daysUntilExam) { return topic.calculatePriority(daysUntilExam); }
  allocateSessions(topics, availableMinutes) {
    let remaining = availableMinutes;
    return [...topics].sort((a, b) => this.calculatePriority(b.topic, b.days) - this.calculatePriority(a.topic, a.days))
      .filter(item => item.topic.status !== 'Completed')
      .map(item => {
        const duration = Math.min(item.topic.estimatedMinutes, remaining);
        remaining -= duration;
        return { topic: item.topic, duration };
      }).filter(item => item.duration > 0);
  }
  checkOverload(topics, availableMinutes) {
    return topics.reduce((sum, topic) => sum + topic.estimatedMinutes, 0) > availableMinutes;
  }
}
class ProgressTracker {
  recordCompletion(session) { session.complete(); }
  calculateCompletionRate(sessions) {
    return sessions.length ? Math.round(sessions.filter(s => s.status === 'Completed').length / sessions.length * 100) : 0;
  }
  getProgressSummary(sessions) {
    return { total: sessions.length, completed: sessions.filter(s => s.status === 'Completed').length,
      percent: this.calculateCompletionRate(sessions) };
  }
}
class PomodoroTimer {
  constructor(workMinutes = 25, breakMinutes = 5) {
    this.workMinutes = workMinutes;
    this.breakMinutes = breakMinutes;
    this.state = 'Ready';
  }
  start() { this.state = 'Running'; }
  pause() { this.state = 'Paused'; }
  reset() { this.state = 'Ready'; }
}

// Sample objects used by this interface (demonstration data, not a real account).
const demoUser = new User(1, 'Mourin', 'student@example.com');
const demoJava = new Subject(1, 'Java Programming', '2026-11-12', 4);
const demoOop = new Topic(1, 'OOP concepts', 4, 45);
demoJava.addTopic(demoOop);
const demoPlan = new StudyPlan(101, demoUser);
demoPlan.addSession(new StudySession(1, demoOop, 45));
const scheduleGenerator = new ScheduleGenerator();
const progressTracker = new ProgressTracker();
const demoTimer = new PomodoroTimer();

const taskList = document.getElementById('taskList');
const initialTaskCount = 6;

function updateProgress() {
  const tasks = [...taskList.querySelectorAll('.task')];
  const done = tasks.filter(task => task.classList.contains('completed')).length;
  const total = tasks.length;
  const percent = total ? Math.round(done / total * 100) : 0;
  document.getElementById('doneCount').textContent = done;
  document.getElementById('progressPercent').textContent = percent + '%';
  document.getElementById('progressFill').style.width = percent + '%';
  document.getElementById('subjectCount').textContent = document.querySelectorAll('.subject-row').length;
  document.getElementById('studyHours').innerHTML = (tasks.filter(t => t.classList.contains('completed')).reduce((sum, t) => {
    const min = parseInt(t.querySelector('.time small')?.textContent || '0', 10);
    return sum + (Number.isFinite(min) ? min : 0);
  }, 0) / 60).toFixed(1) + ' <em>hrs</em>';
}

taskList.addEventListener('click', (event) => {
  const button = event.target.closest('.complete-btn');
  if (!button) return;
  const task = button.closest('.task');
  task.classList.toggle('completed');
  if (task.classList.contains('completed') && task.dataset.task === '0') {
    progressTracker.recordCompletion(demoPlan.getDailyPlan()[0]);
  }
  const tag = task.querySelector('.tag');
  if (task.classList.contains('completed')) {
    tag.textContent = 'Completed';
    tag.className = 'tag tag-green';
    button.setAttribute('aria-label', 'Mark task incomplete');
  } else {
    tag.textContent = 'In progress';
    tag.className = 'tag tag-purple';
    button.setAttribute('aria-label', 'Mark task complete');
  }
  updateProgress();
});

document.getElementById('addTaskForm').addEventListener('submit', (event) => {
  event.preventDefault();
  const input = document.getElementById('newTask');
  const name = input.value.trim();
  if (!name) return;
  const task = document.createElement('article');
  task.className = 'task';
  task.innerHTML = `
    <div class="time">Flexible<small>25 min</small></div>
    <div class="task-dot violet"></div>
    <div class="task-info"><strong></strong><p>New task added to your sample plan</p><span class="tag tag-purple">In progress</span></div>
    <button class="complete-btn" aria-label="Mark task complete">✓</button>`;
  task.querySelector('.task-info strong').textContent = name;
  taskList.appendChild(task);
  input.value = '';
  updateProgress();
});

let timerSeconds = 25 * 60;
let timerInterval = null;
let running = false;
function renderTimer() {
  const mins = Math.floor(timerSeconds / 60).toString().padStart(2, '0');
  const secs = (timerSeconds % 60).toString().padStart(2, '0');
  document.getElementById('timerDisplay').textContent = `${mins}:${secs}`;
}
function stopTimer() {
  if (timerInterval) clearInterval(timerInterval);
  timerInterval = null;
  running = false;
  document.getElementById('timerStart').textContent = '▶ Start';
}
document.getElementById('timerStart').addEventListener('click', () => {
  if (running) {
    stopTimer();
    document.getElementById('timerState').textContent = 'Paused';
    return;
  }
  running = true;
  document.getElementById('timerStart').textContent = 'Ⅱ Pause';
  document.getElementById('timerState').textContent = 'Focus in progress';
  timerInterval = setInterval(() => {
    if (timerSeconds > 0) {
      timerSeconds--;
      renderTimer();
    } else {
      stopTimer();
      document.getElementById('timerState').textContent = 'Session complete!';
      document.getElementById('timerStart').textContent = '▶ Start again';
    }
  }, 1000);
});
document.getElementById('timerReset').addEventListener('click', () => {
  stopTimer();
  timerSeconds = 25 * 60;
  renderTimer();
  document.getElementById('timerState').textContent = 'Ready to focus';
});
document.getElementById('focusBtn').addEventListener('click', () => {
  document.body.classList.toggle('focus-mode');
  const focused = document.body.classList.contains('focus-mode');
  document.getElementById('focusBtn').textContent = focused ? '✕ Exit focus' : '◷ Focus mode';
});
updateProgress();
